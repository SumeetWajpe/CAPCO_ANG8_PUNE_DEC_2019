export class ProductModel{
    constructor(
        public title?:string,
        public price?:number,
        public quantity?:number,
        public likes?:number,
        public rating?:number,
        public imageUrl?:string,

    ){

        }
}