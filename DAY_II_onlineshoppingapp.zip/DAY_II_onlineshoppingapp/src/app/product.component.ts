import { Component, Input } from "@angular/core";


@Component({
    selector:'product',
    templateUrl:'./product.template.html'
})
export class ProductComponent{
  @Input()  productdetails:any = {};
  IncrementLikes(){
      // model changes UI changes(Binding)
      this.productdetails.likes+=1;
  }
}