import { Component } from "@angular/core";


@Component({
    selector:'shoppingcart',
    templateUrl:'./shoppingcart.template.html'
})
export class ShoppingCartComponent{
    heading:string="Online Shopping";
      products:any=[
          {title:'LED TV',price:50000,quantity:300,rating:4,imageUrl:'https://images-na.ssl-images-amazon.com/images/I/818yneFa4iL._AC_SL1500_.jpg',likes:100},
          {title:'DSLR',price:100000,quantity:400,rating:3,imageUrl:'https://images-na.ssl-images-amazon.com/images/I/81Po%2BtPr61L._AC_SX450_.jpg',likes:400},
          {title:'Drone',price:120000,quantity:500,rating:4.566,imageUrl:'https://cdn.shopify.com/s/files/1/0256/0966/6611/products/v-335970692__-466243740_1024x1024_ff7b5ed1-8579-408c-9079-e24212be0789_540x.jpg?v=1575041481',likes:800},
          {title:'Mobile',price:15000,quantity:700,rating:5,imageUrl:'https://images-na.ssl-images-amazon.com/images/I/61itOh%2BJe8L._AC_SL1024_.jpg',likes:200},
          {title:'Go Pro 7',price:35000,quantity:400,rating:3.554,imageUrl:'https://images-na.ssl-images-amazon.com/images/I/71UAtd5yS5L._AC_SL1500_.jpg',likes:900}
        ];
        ChangeHeading(e){
            this.heading = e.target.value;
        }
}