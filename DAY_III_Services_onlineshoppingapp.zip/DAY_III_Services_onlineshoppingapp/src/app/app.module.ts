import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import { ShoppingCartComponent } from './shoppingcart.component';
import { ProductComponent } from './product.component';
import { QuantityPipe } from './quantity.pipe';
import { CompanyComponent } from './company/company.component';
import { CompanyService } from './company/company.service';
import { ProductService } from './product.service';
import { CartItemsComponent } from './cart-items/cart-items.component';
import { CartItemsService } from './cart-items/cartitems.service';

@NgModule({
  declarations: [
    AppComponent,ShoppingCartComponent,ProductComponent,QuantityPipe, 
    CompanyComponent, CartItemsComponent
  ],
  imports: [
    BrowserModule,FormsModule
  ],
  providers: [CompanyService,ProductService,CartItemsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
