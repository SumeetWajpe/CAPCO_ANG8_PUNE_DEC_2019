import { Component } from "@angular/core";
import { ProductService } from './product.service';
import { ProductModel } from './product.model';


@Component({
    selector:'shoppingcart',
    templateUrl:'./shoppingcart.template.html'
})
export class ShoppingCartComponent{
    heading:string="Online Shopping";
      products:ProductModel[]=[];
      constructor(public prodServObj:ProductService){
        this.products = this.prodServObj.getAllProducts();
      }
        ChangeHeading(e){
            this.heading = e.target.value;
        }
}