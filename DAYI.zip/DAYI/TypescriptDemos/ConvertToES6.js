let testVar = "Hello !";
var SquareFunc = (x) => x * x;
