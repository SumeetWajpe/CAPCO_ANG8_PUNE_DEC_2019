// superset of JS (ES6)
//var x = 100; // number // Type inference
//x = "Hello !";
var x; // Type annotation
x = 200;
console.log(x);
var b;
var s;
var o;
var a;
a = 10;
a = "Hi";
a = { name: 'CAPCO' };
a = [10, 20, 30];
// ES 6
//let allows block scoping
if (true) {
    let blockScoped;
    blockScoped = 1000;
    if (true) {
        console.log(blockScoped);
    }
}
const PI = 3.14;
// Functions
function Addition(x, y) {
    if (x < 0) {
        return 'x should be greater than 0 !';
    }
    return x + y;
}
//Addition();
//Addition("Hi","Bye");
var result = Addition(10, 20);
// Parameters
// Optional -> ?
// function PrintBooks(author?:string,title?:string){
//     author = author || "ABCD";// short circuit
//     title = title || "XYZ";
//     console.log(author,title);
// }
//PrintBooks();
// Default Parameters (Optional)
function PrintBooks(author = "Dr. APJ Abdul Kalam", title = "Wings Of Fire") {
    console.log(author, title);
}
PrintBooks();
PrintBooks("Sachin Tendulkar", "Playing it my way");
PrintBooks(undefined, "India 2020");
// Arrow Functions = Lambda expressions
// function Square(x){
//     return x * x;
// }
// Function as an expression
// var Square = function(x){
//         return x * x;
// }
// Arrow Function (ES6)
// var Square = (x) => {
//     return x * x;
// }
// OR
var Square = (x) => x * x;
console.log(Square(20));
// Usage
// var cars:string[] = ["BMW","AUDI","FERRARI"];
var cars = new Array("BMW", "AUDI", "FERRARI");
cars.forEach(function (c, i) {
    console.log(c + " is at index " + i);
});
// OR
cars.forEach((c, i) => console.log(c + " is at index " + i));
function Emp() {
    this.salary = 50000;
    setTimeout(() => {
        console.log(this.salary);
    }, 3000);
}
class Company {
    getDetails() {
        console.log(this.name + " is in " + this.city);
    }
}
var company = { name: 'CAPCO', getDetails: function () {
        console.log(this.name);
    } }; //  Literal SYntax
company.getDetails();
// Classes
class Car {
    constructor(name = "i20", speed = 100) {
        this.name = name;
        this.speed = speed;
    }
    accelerate() {
        //console.log("The Car " + this.name + " is running at " + this.speed + " kmph !");
        return (`The Car ${this.name} is running at ${this.speed} kmph !`);
    }
}
// var carObj:Car = new Car();
// carObj.accelerate();
// will preserve the line breaks !
// var multiLine = `FirstLine !
// Second Line !
// Last Line !`;
// console.log(multiLine);
class JamesBondCar extends Car {
    constructor(n, s, fly, nitro) {
        super(n, s); // call base class paramterized ctor !
        this.useNitroPower = nitro;
        this.canFly = fly;
    }
    accelerate() {
        return super.accelerate() + " Can It Fly ? :"
            + this.canFly;
    }
}
var jbc = new JamesBondCar("Aston Martin", 500, true, true);
console.log(jbc.accelerate());
// Enhanced Class Syntax
class EnhancedCar {
    constructor(name, speed) {
        this.name = name;
        this.speed = speed;
    }
}
var eCar = new EnhancedCar("Audi", 300);
class Point {
}
var p = new Point();
var p2 = new Point();
