// superset of JS (ES6)

//var x = 100; // number // Type inference
//x = "Hello !";
var x:number; // Type annotation
x = 200;
console.log(x);

var b:boolean;
var s:string;
var o:object;
var a:any;
a = 10;
a = "Hi";
a = {name:'CAPCO'};
a = [10,20,30];

// ES 6
//let allows block scoping

if(true){
    let blockScoped;
    blockScoped = 1000;
    if(true){
        console.log(blockScoped);
    }
}

const PI = 3.14;

// Functions
function Addition(x:number,y:number):number|string{
    if(x <0){
        return 'x should be greater than 0 !';
    }
    return x + y;
}
//Addition();
//Addition("Hi","Bye");
var result:string|number = Addition(10,20);

// Parameters
// Optional -> ?
// function PrintBooks(author?:string,title?:string){
//     author = author || "ABCD";// short circuit
//     title = title || "XYZ";
//     console.log(author,title);
// }

//PrintBooks();

// Default Parameters (Optional)

function PrintBooks(author:string="Dr. APJ Abdul Kalam",title:string="Wings Of Fire"){   
    console.log(author,title);
}

PrintBooks();
PrintBooks("Sachin Tendulkar","Playing it my way");
PrintBooks(undefined,"India 2020");

// Arrow Functions = Lambda expressions

// function Square(x){
//     return x * x;
// }

// Function as an expression
// var Square = function(x){
//         return x * x;
// }

// Arrow Function (ES6)
// var Square = (x) => {
//     return x * x;
// }
// OR
var Square = (x:number):number => x * x;
console.log(Square(20));

// Usage

// var cars:string[] = ["BMW","AUDI","FERRARI"];
var cars:Array<string> = new Array<string>("BMW","AUDI","FERRARI")
cars.forEach(function(c,i){
    console.log(c + " is at index " + i);
});
// OR
cars.forEach((c,i)=>console.log(c + " is at index " + i));

function Emp(){
    this.salary = 50000;         
    setTimeout(()=>{
       console.log(this.salary);
    },3000)      
}

// Classes & Interfaces

interface ICompany{
    name:string;
    city?:string;
    getDetails():void;
}

class Company implements ICompany{
    name:string;
    city?:string;
    getDetails(){
        console.log(this.name + " is in " + this.city)
    }
}


var company:ICompany = {name:'CAPCO',getDetails:function(){
    console.log(this.name);
}}; //  Literal SYntax


company.getDetails();
// Classes

class Car{
    name:string;
    speed:number;
    constructor(name:string="i20",speed:number=100){
        this.name = name;
        this.speed = speed;
    }
    accelerate():string{
       //console.log("The Car " + this.name + " is running at " + this.speed + " kmph !");
       return (`The Car ${this.name} is running at ${this.speed} kmph !`)
    }
}

// var carObj:Car = new Car();
// carObj.accelerate();

// will preserve the line breaks !
// var multiLine = `FirstLine !
// Second Line !
// Last Line !`;
// console.log(multiLine);

class JamesBondCar extends Car{
    canFly:boolean;
    useNitroPower:boolean;
    constructor(n:string,s:number,fly:boolean,nitro:boolean){
        super(n,s);// call base class paramterized ctor !
        this.useNitroPower = nitro;
        this.canFly = fly;
    }
    accelerate():string{
            return super.accelerate() + " Can It Fly ? :"
             + this.canFly;
    }
}
var jbc = new JamesBondCar("Aston Martin",500,true,true);
console.log(jbc.accelerate());

// Enhanced Class Syntax
class EnhancedCar{
    constructor(public name:string,public speed:number){

    }
}

var eCar = new EnhancedCar("Audi",300);

class Point<T>{
    x:T;
    y:T;
}

var p:Point<number>  = new Point<number>();
var p2:Point<string>  = new Point<string>();






