let testVar:string = "Hello !";
var SquareFunc = (x:any) => x * x;